#!/bin/bash
echo "Iniciando a DanCoin..."
dancoind start