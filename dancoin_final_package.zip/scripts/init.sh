#!/bin/bash
dancoind init DanNode --chain-id dancoin-testnet
dancoind keys add wallet --keyring-backend test
dancoind add-genesis-account $(dancoind keys show wallet -a --keyring-backend test) 21000000000000danc
dancoind gentx wallet 100000000000danc --chain-id dancoin-testnet --keyring-backend test
dancoind collect-gentxs