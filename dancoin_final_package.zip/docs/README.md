# DanCoin Blockchain

DanCoin é uma rede Proof of Stake construída com Cosmos SDK.
Inclui arquivos e scripts para rodar localmente, criar carteiras, validadores e executar contratos via CosmWasm.

## Como rodar

```bash
chmod +x scripts/*.sh
./scripts/init.sh
./scripts/start.sh
```

## API e Explorer

- RPC: http://localhost:26657
- REST: http://localhost:1317/swagger

## Conectar nós

Adicione em `config.toml`:
persistent_peers = "ab12cd34ef56@192.168.0.100:26656"